# ACCIDENT-DETECTION
IoT based accident detection and emergency SOS Device
